
public class Quiz {
	
	private int currentQuestion=-1;
	private int score;
	private boolean isLastQuestion;
	
	private static String[] questions= {
			"3, 1, 4, 1, 5", //PI
			"1, 1, 2, 3, 5", //Fibonacci
			"1, 4, 9, 16, 25", //Squares
			"2, 3, 5, 7, 11", //Primes
			"1, 2, 4, 8, 16", //Powers of 2
	};
	
	private static int[]answers= {9, 8, 36, 13, 32};
	
	public String nextQuestion() {
		currentQuestion++;
		if(currentQuestion>= questions.length) {
			isLastQuestion= true;
			return "";
		}
		
		return questions[currentQuestion];
	}
	
	public boolean isValid(int answer) {
		
		return answers[currentQuestion]== answer;
	}
	
	public void increaseScore() {
		score++;
	}
	
	public int getScore() {
		return score;
	}
	
	public boolean isLastQuestion() {
		return isLastQuestion;
	}

}
