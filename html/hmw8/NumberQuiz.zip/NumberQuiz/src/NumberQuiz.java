import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/index")
public class NumberQuiz extends HttpServlet {
	
	public final static String NUMBER_QUIZ_JSP= "/WEB-INF/numberquiz.jsp";
	
	private Quiz quiz;
	
	@Override
	public void init() throws ServletException {
		quiz= new Quiz();
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String question= quiz.nextQuestion();
		
		req.setAttribute("question", question);
		req.setAttribute("score", 0);
		req.setAttribute("isLastQuestion", quiz.isLastQuestion());
		
		req.getRequestDispatcher(NUMBER_QUIZ_JSP).forward(req, resp);
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException ,IOException {
		int answer= Integer.parseInt(req.getParameter("answer"));
		
		if(quiz.isValid(answer))quiz.increaseScore();
		
		req.setAttribute("score", quiz.getScore());
		
		if(!quiz.isLastQuestion()) {
			req.setAttribute("question", quiz.nextQuestion());
		}
		req.setAttribute("isLastQuestion", quiz.isLastQuestion());
		
		req.getRequestDispatcher(NUMBER_QUIZ_JSP).forward(req, resp);
	}
}
